package pcComponents;
public interface PCInterface {
    public void start();
    public void stop();
}
